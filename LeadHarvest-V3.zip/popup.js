document.getElementById("start").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  const config = {
    maxPages: parseInt(document.getElementById("maxPages").value) || 1,
    minDelay: parseInt(document.getElementById("minDelay").value) || 3000,
    maxDelay: parseInt(document.getElementById("maxDelay").value) || 7000
  };

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: scraper,
    args: [config]
  });
});

async function scraper(config){

function delay(min,max){
  return new Promise(r=>setTimeout(r,Math.random()*(max-min)+min));
}

function detectCards(){
  let selectors=[
    'li[data-x-search-result]',
    '.entity-result',
    '.reusable-search__result-container',
    '.artdeco-list__item'
  ];

  for(let sel of selectors){
    let els=document.querySelectorAll(sel);
    if(els.length>5){
      console.log("Using:",sel,"Count:",els.length);
      return els;
    }
  }

  console.log("Fallback to generic div scan");
  return document.querySelectorAll("li,div");
}

function extract(card){
  let text=card.innerText || "";
  let lines=text.split("\n").map(l=>l.trim()).filter(l=>l);

  return {
    name: lines[0] || "",
    title: lines[1] || "",
    company: lines[2] || "",
    location: lines.find(l=>l.includes("India")||l.includes("United")) || "",
    industry: ""
  };
}

function download(data){
  if(data.length===0){
    alert("No data found. Scroll page and try again.");
    return;
  }

  let rows=[["Name","Title","Company","Location","Industry"],
    ...data.map(d=>[d.name,d.title,d.company,d.location,d.industry])];

  let csv=rows.map(r=>r.join(",")).join("\n");
  let blob=new Blob([csv],{type:'text/csv'});
  let url=URL.createObjectURL(blob);

  let a=document.createElement("a");
  a.href=url;
  a.download="leads.csv";
  a.click();
}

async function nextPage(){
  let btn=document.querySelector('button[aria-label="Next"]') ||
          document.querySelector('button.artdeco-pagination__button--next');

  if(!btn||btn.disabled) return false;

  btn.click();
  await delay(7000,12000);
  return true;
}

let page=1;
let results=[];

while(page<=config.maxPages){

  window.scrollTo(0,document.body.scrollHeight);
  await delay(3000,6000);

  let cards=detectCards();
  console.log("Detected cards:",cards.length);

  for(let card of cards){
    let data=extract(card);
    if(data.name) results.push(data);
    await delay(config.minDelay,config.maxDelay);
  }

  let hasNext=await nextPage();
  if(!hasNext) break;

  page++;
}

download(results);

}
