const logBox = document.getElementById("log");

function log(msg){
  logBox.innerHTML += msg + "<br>";
}

document.getElementById("start").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  const config = {
    maxPages: parseInt(document.getElementById("maxPages").value) || 1,
    minDelay: parseInt(document.getElementById("minDelay").value) || 3000,
    maxDelay: parseInt(document.getElementById("maxDelay").value) || 7000
  };

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: scraper,
    args: [config]
  });

  log("Started scraping...");
});

async function scraper(config) {

  function delay(min, max){
    return new Promise(res => setTimeout(res, Math.random()*(max-min)+min));
  }

  function getCards(){
    return document.querySelectorAll('li[data-x-search-result]');
  }

  function extract(card){
    return {
      name: card.querySelector('[data-anonymize="person-name"]')?.innerText || "",
      title: card.querySelector('[data-anonymize="title"]')?.innerText || "",
      company: card.querySelector('[data-anonymize="company-name"]')?.innerText || "",
      location: card.querySelector('[data-anonymize="location"]')?.innerText || "",
      industry: ""
    };
  }

  function downloadCSV(data){
    const rows = [["Name","Title","Company","Location","Industry"],
      ...data.map(d => [d.name,d.title,d.company,d.location,d.industry])];

    let csv = rows.map(r => r.join(",")).join("\n");
    let blob = new Blob([csv], {type:'text/csv'});
    let url = URL.createObjectURL(blob);

    let a = document.createElement("a");
    a.href = url;
    a.download = "leads.csv";
    a.click();
  }

  async function nextPage(){
    let btn = document.querySelector('button[aria-label="Next"]') || 
              document.querySelector('button.artdeco-pagination__button--next');

    if(!btn || btn.disabled) return false;

    btn.click();
    await delay(6000,10000);
    return true;
  }

  let page = 1;
  let results = [];

  while(page <= config.maxPages){

    window.scrollTo(0, document.body.scrollHeight);
    await delay(3000,5000);

    let cards = getCards();
    console.log("Cards found:", cards.length);

    for(let card of cards){
      results.push(extract(card));
      await delay(config.minDelay, config.maxDelay);
    }

    let hasNext = await nextPage();
    if(!hasNext) break;

    page++;
  }

  downloadCSV(results);
}
